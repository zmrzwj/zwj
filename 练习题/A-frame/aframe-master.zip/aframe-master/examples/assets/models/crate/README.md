# Crate

Made by Tyro Smith, free for personal and commercial use.

Source: http://tf3dm.com/3d-model/crate-86737.html
