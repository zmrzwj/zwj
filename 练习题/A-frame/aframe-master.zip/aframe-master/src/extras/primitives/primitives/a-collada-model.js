var registerPrimitive = require('../primitives').registerPrimitive;

registerPrimitive('a-collada-model', {
  mappings: {
    src: 'collada-model'
  }
});
